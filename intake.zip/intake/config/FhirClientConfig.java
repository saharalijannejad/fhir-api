package ca.uhn.fhir.jpa.starter.intake.config;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class FhirClientConfig {


	@Bean
	public FhirContext fhirContext() {
		FhirContext ctx = FhirContext.forR4();
		ctx.getRestfulClientFactory().setConnectTimeout(10_000);
		ctx.getRestfulClientFactory().setSocketTimeout(30_000);
		return ctx;
	}



	@Bean(name = "igenericclient")
	public IGenericClient igenericclient(FhirContext ctx,
													 @Value("${fhir.base-url}") String baseUrl) {
		return ctx.newRestfulGenericClient(baseUrl);
	}
}