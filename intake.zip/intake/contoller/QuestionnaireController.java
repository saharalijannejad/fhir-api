package ca.uhn.fhir.jpa.starter.intake.contoller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import ca.uhn.fhir.parser.IParser;
import org.hl7.fhir.r4.model.Questionnaire;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/api/questionnaires")
public class QuestionnaireController {

	private final IGenericClient fhirClient;
	private final IParser fhirParser;

	@Autowired
	public QuestionnaireController(IGenericClient fhirClient, ca.uhn.fhir.context.FhirContext fhirContext) {
		this.fhirClient = fhirClient;
		this.fhirParser = fhirContext.newJsonParser();
	}

	@PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE, "application/fhir+json"},
		produces = {MediaType.APPLICATION_JSON_VALUE, "application/fhir+json"})
	public Questionnaire create(@RequestBody String body) {

		Questionnaire questionnaire = fhirParser.parseResource(Questionnaire.class, body);

		MethodOutcome outcome = fhirClient.create()
			.resource(questionnaire)
			.execute();

		return (Questionnaire) outcome.getResource();
	}
}
