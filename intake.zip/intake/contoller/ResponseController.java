package ca.uhn.fhir.jpa.starter.intake.contoller;

import ca.uhn.fhir.jpa.starter.intake.service.ResponseService;
import org.hl7.fhir.r4.model.QuestionnaireResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/responses")
public class ResponseController {

	private final ResponseService responseService;

	@Autowired
	public ResponseController(ResponseService responseService) {
		this.responseService = responseService;
	}


	@PostMapping("/{questionnaireId}")
	public QuestionnaireResponse submitResponse(
		@PathVariable("questionnaireId") String questionnaireId,
		@RequestBody Map<String, String> answers) {

		System.out.println("📥 دریافت پاسخ‌ها برای Questionnaire/" + questionnaireId);
		System.out.println("Answers: " + answers);

		return responseService.submit(questionnaireId, answers);
	}
}
