package ca.uhn.fhir.jpa.starter.intake.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import java.util.List;


@Data
public class CreateQuestionnaireRequest {
	@NotBlank private String title;
	private String description;


	@NotEmpty
	private List<QuestionItemDto> items;



	@Data
	public static class QuestionItemDto {
		@NotBlank private String linkId;
		@NotBlank private String text;
		@NotBlank private String type;
		private List<String> choices;
	}
}