package ca.uhn.fhir.jpa.starter.intake.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import java.util.List;


@Data
public class SubmitResponseRequest {
	@NotBlank private String questionnaireId;
	private String patientIdentifier;
	private String patientGivenName;
	private String patientFamilyName;


	@NotEmpty
	private List<AnswerDto> answers;


	@Data
	public static class AnswerDto {
		@NotBlank private String linkId;
		private String valueText;
		private String valueChoice;
	}
}