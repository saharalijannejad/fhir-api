package ca.uhn.fhir.jpa.starter.intake.dto;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data @AllArgsConstructor
public class SubmitResponseResult {
	private String questionnaireResponseId;
	private String patientId;
}