package ca.uhn.fhir.jpa.starter.intake.service;

import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import ca.uhn.fhir.rest.gclient.TokenClientParam;
import lombok.RequiredArgsConstructor;
import org.hl7.fhir.r4.model.*;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
public class PatientService {


	private final IGenericClient igenericclient;
	private static final String ID_SYSTEM = "http://hospital.example/patient-id";


	public String findOrCreate(String identifierValue, String given, String family) {
		if (identifierValue == null || identifierValue.isBlank()) return null;


		Bundle bundle = igenericclient.search().forResource(Patient.class)
			.where(new TokenClientParam("identifier").exactly().systemAndCode(ID_SYSTEM, identifierValue))
			.returnBundle(Bundle.class)
			.execute();


		if (bundle.hasEntry() && bundle.getEntryFirstRep().getResource() instanceof Patient p) {
			return p.getIdElement().getIdPart();
		}


		Patient p = new Patient();
		p.addIdentifier(new Identifier().setSystem(ID_SYSTEM).setValue(identifierValue));
		if (given != null || family != null) {
			p.addName(new HumanName().addGiven(given == null ? "" : given).setFamily(family == null ? "" : family));
		}


		MethodOutcome out = igenericclient.create().resource(p).execute();
		IdType id = (IdType) out.getId();
		return id.getIdPart();
	}
}