package ca.uhn.fhir.jpa.starter.intake.service;

import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import lombok.RequiredArgsConstructor;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Questionnaire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ca.uhn.fhir.jpa.starter.intake.dto.CreateQuestionnaireRequest;
import ca.uhn.fhir.jpa.starter.intake.dto.CreateQuestionnaireResult;

import java.util.List;
import java.util.UUID;
import org.hl7.fhir.r4.model.Enumerations.PublicationStatus;


@Service
public class QuestionnaireService {

	private final IGenericClient fhirClient;

	@Autowired
	public QuestionnaireService(IGenericClient fhirClient) {
		this.fhirClient = fhirClient;
	}

	public Questionnaire create(String title, List<String> questions) {
		Questionnaire q = new Questionnaire();
		q.setTitle(title);
		q.setStatus(PublicationStatus.ACTIVE);

		int linkId = 1;
		for (String question : questions) {
			Questionnaire.QuestionnaireItemComponent item = new Questionnaire.QuestionnaireItemComponent();
			item.setLinkId(String.valueOf(linkId++));
			item.setText(question);
			item.setType(Questionnaire.QuestionnaireItemType.STRING);
			q.addItem(item);
		}

		return (Questionnaire) fhirClient.create()
			.resource(q)
			.execute()
			.getResource();
	}
}
