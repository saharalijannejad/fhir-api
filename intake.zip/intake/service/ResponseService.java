package ca.uhn.fhir.jpa.starter.intake.service;

import org.hl7.fhir.r4.model.*;
import org.hl7.fhir.r4.model.QuestionnaireResponse.*;
import ca.uhn.fhir.rest.api.MethodOutcome;
import ca.uhn.fhir.rest.client.api.IGenericClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class ResponseService {

	private final IGenericClient fhirClient;

	@Autowired
	public ResponseService(IGenericClient fhirClient) {
		this.fhirClient = fhirClient;
	}


	public QuestionnaireResponse submit(String questionnaireId, Map<String, String> answers) {
		QuestionnaireResponse response = new QuestionnaireResponse();
		response.setStatus(QuestionnaireResponseStatus.COMPLETED);


		response.setQuestionnaire("Questionnaire/" + questionnaireId);


	//	response.setSubject(new Reference("Patient/1"));


		for (Map.Entry<String, String> entry : answers.entrySet()) {
			QuestionnaireResponseItemComponent item = new QuestionnaireResponseItemComponent();
			item.setLinkId(entry.getKey());

			QuestionnaireResponseItemAnswerComponent answer = new QuestionnaireResponseItemAnswerComponent();
			answer.setValue(new StringType(entry.getValue()));

			item.addAnswer(answer);
			response.addItem(item);
		}

		try {
			MethodOutcome outcome = fhirClient.create()
				.resource(response)
				.execute();

			System.out.println(" QuestionnaireResponse ذخیره شد با id=" + outcome.getId().getIdPart());

			return (QuestionnaireResponse) outcome.getResource();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(" خطا در ذخیره QuestionnaireResponse: " + e.getMessage(), e);
		}
	}
}